<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tractocamiones";
$tbl_name = "caracteristicas";
    

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
    

    
$modelo = $_POST["modelo"];
$precio = $_POST["precio"];
$age = $_POST["age"];
$kilometraje = $_POST["kilometraje"];
$descripcion = $_POST["descripcion"];
$marca = $_POST["marca"];
$tipo = $_POST["tipo"];
$imagen = $_FILE["imagen1"];

    
$sql = "INSERT INTO $tbl_name (modelo, precio, age, kilometraje, descripcion, marca, tipo, imagen1) VALUES ('$modelo', '$precio', '$age', '$kilometraje', '$descripcion', '$marca', '$tipo', '$imagen')";

    
    
if($conn->query($sql) === TRUE){
    echo "Datos guardados";
} else {
    echo "Error" . $sql . "<br>" .$conn->error; 
}



/*    
$sql = "INSERT INTO caracteristicas (modelo, precio, age, kilometraje, descripcion, marca, tipo) VALUES ('T880', 850000, 1994, 453571, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras blandit felis at diam volutpat viverra. Mauris sodales enim odio, a accumsan diam vestibulum quis. Curabitur in lobortis neque, ut euismod purus. Nullam blandit metus id tempor tincidunt. Ut neque est, condimentum ac ultrices ut, lobortis et ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nunc aliquet eu neque nec tempus. Nam feugiat fermentum sem.', 'Kenworth', 'Tractocamion')";
    
if($conn->query($sql) === TRUE){
    echo "New record created successfully";
} else {
    echo "Error" . $sql . "<br>" .$conn->error; 
}
*/
$conn->close();    

?>